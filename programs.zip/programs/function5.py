## variable length arguments
# if any object is prefixed with * it becomes tuple

def display(*arg):
    for val in arg:
        print(val)

display(10,20,30,40,50,60,70,80,90,100,"unix","linux")



def getdisplay(**kwargs):
    print(kwargs)
getdisplay(chap1 = 10 ,chap2 = 20)



def bookValues(**info):
    print(info)
book = {"chap1":10 ,"chap2":20}
bookValues(**book)