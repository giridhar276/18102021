
# name[start:stop:step]


# slicing
name = "python programming"
print(name)

print(name[0])
print(name[0:5])
print(name[4:9])
print(name[::])  # python programming
print(name[:])
print(name[0:17:2])
print(name[1:17:2])
print(name[::3])
print(name[-1])
print(name[-5:-1])
print(name[::-1])
print(name[::-2])