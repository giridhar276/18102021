#!/usr/bin/env python3

## reading json file and converting into csv file
import json
import sys
try:
    with open("jsonfiles/Sample_Json_with_200_Records.json","r",errors='ignore') as fobj:
        with open("info.csv","w") as fwrite:
            data= json.load(fobj)
            for key,value in data.items():
                if isinstance(value,list):
                    for item in value:
                        idval = str(item['id'])
                        title = item['title']
                        description = item['description']
                        location = item['location']
                        string = ",".join([idval,title,description,location])
                        
                        fwrite.write(string + "\n")
                        
    #output = 1 + "hello"   
    #alist = [10,20,30]
    #print(alist[100])                    
except FileNotFoundError  as error:
    print("System defined error:", error)
    print("User defined error :", " error found")
    #print(sys.exc_info()[0])
except TypeError as err:
    print(err)
    print(sys.exc_info()[0])
except (ValueError,NameError,IndexError) as err:
    print(err)
    print(sys.exc_info()[0])
except Exception as err:     ### Base calss exception or default exception
    print(err)
    print(sys.exc_info()[0])
    

