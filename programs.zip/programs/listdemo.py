
alist = [10,20,30,40,"python",56.54]

print("list values are :", alist)

# list slicing
print(alist[0:5])
print(alist[::-1])


blist = [70,80,90]

final = alist + blist
print(final)

atup = (10,30,40)

final = alist + list(atup)
print(final)

print(alist)

alist[0] = 10000
print("After replacing :", alist)