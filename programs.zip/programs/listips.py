'''
192.168.0.1
192.168.0.2
..
..
..
192.168.0.100
'''

for val in range(1,101):
    ip = "192.168.0." + str(val)
    print(ip)
  
    
'''
192.168.0.1
192.168.0.2
..
..
192.168.0.10
192.168.1.1
192.168.1.2
..
..
192.168.1.10
'''
for val in range(0,2):
    ip = "192.168." + str(val)
    for val in range(1,11):
        ipadd = ip + "." + str(val)
        print(ipadd)
        
        
        
        
        
        
        
        
        
        
        
        
        