




name = input("Enter any filename :")
print(name)