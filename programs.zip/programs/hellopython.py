#!/usr/bin/env python3


#print("python programming")




print(1,2)

print("hello","python programming")

