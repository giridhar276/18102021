# 1st method
# fobj acts as cursor or pointer or handler
with open("languages.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        print(line)
    
# 2nd method  ( output will be string format)
with open("languages.txt","r") as fobj:
    print(fobj.read())        
        
# 3rd method
## Output will be in list format
with open("languages.txt","r") as fobj:
    print(fobj.readlines())
    
with open("languages.txt","r") as fobj:
    for line in fobj.readlines():
        print(line.strip())
        
# 4th method
import csv

with open("languages.txt","r") as fobj:
    ## converting file object to csv object( csv understandable format)
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        

import pandas
df = pandas.read_csv("languages.txt")
print(df)
        

        