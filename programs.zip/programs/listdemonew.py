alist = [10,20,30,40,45,3,300,65,65,45,5454]
# append - add single value
alist.append(65)

print("after appending :", alist)
# add multiple values in list
alist.extend([56,43,32,7])
print("after extending :", alist)
# get coung
getcount = alist.count(100)
print(getcount)
# insert(where to insert , what to insert)
alist.insert(0,10000)
print("AFTER INSERTING :",alist)
print("total no ofelements :", len(alist))
# pass index number

print(alist)
alist.pop(1)
print("AFTER POP OPERATION :", alist)

alist.pop(0)
print("after pop opreation :",alist)

alist.remove(30)  # 30 is the value in the list
print("After removing :", alist)
alist.sort()
print("AFTER SORTING :", alist)
alist.reverse()
print("REVERSE ORDER :", alist)

print(alist)
print(alist.index(65))


# display value line by line using for loop
for val in alist:
    print(val)


for i in range(1,10):
    print(i)




