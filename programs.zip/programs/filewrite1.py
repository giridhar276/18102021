fw = open("customers.txt","w")
fw.write("python programming\n")
fw.write("scala programming\n")
fw.close()


#
fw = open("customers2.txt","w")
for val in range(1,10):
    fw.write(str(val) + "\n")



# context manager
# file will be closed automatically
# its not required to used close()
with open("customers3.txt","w") as fwrite:
    for val in range(1,10):
        fwrite.write(str(val) + "\n")


        
        


    
    
    
    
