import json

with open("jsonfiles/Sample_Json_with_200_Records.json","r",errors='ignore') as fobj:
    data= json.load(fobj)
    for key,value in data.items():
        if isinstance(value,list):
            for item in value:
                print("ID         :",item['id'])
                print("Title      :",item['title'])
                print("Description:",item['description'])
                print("location   :",item['location'])
                print("----------------------------")

    



## 2nd method
import json
with open("jsonfiles/Sample_Json_with_200_Records.json","r",errors='ignore') as fobj:
    data= json.load(fobj)
    for item in data['feeds']:
        if isinstance(item,dict):
            print("ID         :",item['id'])
            print("Title      :",item['title'])
            print("Description:",item['description'])
            print("location   :",item['location'])
            print("----------------------------")
