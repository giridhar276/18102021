book = {"chap1":10 ,"chap2":20 ,"chap3":30}

print(book)
#new key-value pair
book["chap4"] = 40
print("BOOK:", book)

print("Only keys :", book.keys())
print("ONLY VALUES:", book.values())
print("key-value pairs:", book.items())
print(book["chap1"])  # 10
#print(book["chap6"])
print(book.get("chap6"))

book2 = {"chap5":50 , "chap6":60}
# all the key:values of book2 will be updatd to book
book.update(book2)
print(book)

## displaly only keys
for key in book.keys():
    print(key)
    
# display only values
for value in book.values():
    print(value)

for key,value in book.items():
    print("Key :", key)
    print("VALUE:",value)
    
    

