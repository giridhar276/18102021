## reading json file and converting into csv file
import json
import sys
try:
    with open("jsonfiles/Sample_Json_with_200_Records.json","r",errors='ignore') as fobj:
        with open("info.csv","w") as fwrite:
            data= json.load(fobj)
            for key,value in data.items():
                if isinstance(value,list):
                    for item in value:
                        idval = str(item['id'])
                        title = item['title']
                        description = item['description']
                        location = item['location']
                        string = ",".join([idval,title,description,location])
                        
                        fwrite.write(string + "\n")
                        
    output = 1 + "hello"                        
except Exception  as error:
    print("System defined error:", error)
    print("User defined error :", " error found")
    print(sys.exc_info()[0])
else:
    print("this is else block")
finally:
    print("finally will be executed all the times")
