import json

with open("jsonfiles/cdk.json") as fobj:
    # converting fobj to the json object
    data = json.load(fobj)
    for key,value in data.items():
        if isinstance(value,str):
            print(key.ljust(60) , value)
            
        elif isinstance(value,dict):
            for skey,svalue in value.items():
                print(skey.ljust(60) , svalue)
                

    
