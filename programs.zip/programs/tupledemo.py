



atup = (10,20,30,40,50,90)

print("tuple elements are :", atup)

print(atup[0:5])
print(atup[::2])


#atup[0] = 2000

print("After replacing :", atup)


alist = list(atup)  # typecast to list
alist[0] = 2000    # making changes
atup = tuple(alist) # recovert back to tuple
print("Modified tuple :", atup)  # display
