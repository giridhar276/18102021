
data = {
   "firstName": "Joe",
   "lastName": "Jackson",
   "gender": "male",
   "age": 28,
   "address": {
       "streetAddress": "101",
       "city": "San Diego",
       "state": "CA"
   },
   "phoneNumbers": [
       { "type": "home", "number": "7349282382" },
       { "type": "office", "number": "9550712233" }
   ]
}
   
   
for key,value in data.items():
    if isinstance(value,str):
        print(key.capitalize().ljust(10),value)
        print(data[key])
    elif isinstance(value,dict):
        print(key.capitalize())
        for skey,svalue in value.items():
            print(skey.capitalize().ljust(10),svalue)
    elif isinstance(value,list):
        for pair in value:
            print(key.capitalize())
            for skey,svalue in pair.items():
                print(skey.capitalize().ljust(10),svalue)

# with hardcoding
print(data['firstName'])
print(data['lastName'])
print(data['address']['streetAddress'])
print(list(data['phoneNumbers'][1].keys())[0])