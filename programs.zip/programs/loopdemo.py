## for with range
for val in range(1,10):
    print(val)
    
# for with string
name= "python"
for char in name:
    print(char)

# for with loop
alist = [10,20,30]
for val in alist:
    print(val)
    
# for with dictionary
book = {"chap1":10 , "chap2":20}
for key in book.keys():
    print(key)
    
for value in book.values():
    print(value)
    
for key,value in book.items():
    print(key,value)
    
    
## for with set
aset = {10,10,10,20,30}
for val in aset:
    print(val)
    
