#!/usr/bin/python3
print("programming")

name = "python"
print(name.lower())
