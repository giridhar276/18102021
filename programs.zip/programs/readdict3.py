


ytag = {
  "kind": "youtube#searchListResponse",
  "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
  "nextPageToken": "CAUQAA",
  "regionCode": "KE",
  "pageInfo": {
    "totalResults": 4249,
    "resultsPerPage": 5
  },
  "items": [
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#channel",
        "channelId": "UCJowOS1R0FnhipXVqEnYU1A"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfBU",
      "id": {
        "kind": "youtube#video",
        "videoId": "Eqa2nAAhHN0"
      }
    },
    {
      "kind": "youtube#searchResult",
      "etag": "m2yskBQFythfE4irbTIeOgYYfB",
      "id": {
        "kind": "youtube#video",
        "videoId": "IirngItQuVs"
      }
    }
  ]
}
  
# 1st method  
for key,value in ytag.items():
    if key == "etag"   and  isinstance(value,str):
        print(ytag[key])
    else:
        if isinstance(value,list):
            for item in value:
                if isinstance(item,dict):
                    print(item['etag'])
        

# 2nd method
print(ytag['etag'])       
for val in range(3):
    print(ytag["items"][val]['etag'])
        
    
    
print(ytag['etag'])       
for val in range(len(ytag['items'])):
    print(ytag["items"][val]['etag'])
        
        