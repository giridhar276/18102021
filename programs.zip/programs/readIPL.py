
#write a progrm to display ONLY player name and age .
import csv

with open("csvfiles/IPLData.csv","r") as fobj:
    # converting file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print("Player:" ,line[1])
        print("Age   :", line[2])

# 1 st method
playerset = set()   
with open("csvfiles/IPLData.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for row in reader:
        playingrole = row[5]
        playerset.add( playingrole)      
#print(playerset)
for value in playerset:
    print(value)

# method2
playerlist = list()   
with open("csvfiles/IPLData.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for row in reader:
        playingrole = row[5]
        playerlist.append(playingrole)
#print(playerset)
for value in set(playerlist):
    print(value)

playerdict = dict()
with open("csvfiles/IPLData.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for line in reader:
        playingrole = line[5]
        # dict[key] = value
        playerdict[playingrole] = 1   # creating dictionary dynamically
for key in playerdict.keys():
    print(key)



# method4
playerlist = list()   
with open("csvfiles/IPLData.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for row in reader:
        playingrole = row[5]
        if playingrole not in playerlist:
            playerlist.append(playingrole)
#print(playerset)
for value in set(playerlist):
    print(value)





