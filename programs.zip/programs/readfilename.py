
'''
write a program to capture some file name (  customers.txt) and display the filename
and extension separately 


Output:

filename :  customers
extension:  txt
'''


filename = input("Enter any filename :")

output= filename.split(".")

print("Filename  :", output[0])
print("Extension :", output[1])