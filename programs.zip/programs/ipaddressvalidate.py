import sys
ip = input("Enter any ip address :")

print(ip)

# 3 dots and 4 values
# each value should be range in 0-2555

data = ip.split(".")
if len(data) != 4 :
    print("INnvalid ip")
    sys.exit(0)
    
if int(data[0]) in range(1,256) and int(data[1]) in range(0,256) and int(data[2]) in range(0,256) and int(data[3]) in range(0,256):
    print("Valid IP")
else:
    print("Invalid IP")
    
    
import sys
ip = input("Enter any ip address :")
data = ip.split(".")   
flag = 1
if int(data[0]) not in range(1,255):
    sys.exit(0)
for val in data[1:]:
    val = int(val)
    if val not in range(1,255):
        print("Invalid Ip")
        flag = 0
        break
if flag == 1 :
    print("Valid ip")
