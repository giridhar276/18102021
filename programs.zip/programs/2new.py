


import os
def displayFiles(path):
    fileslist = []
    for file in os.listdir(path):
        fileslist.append(file)
    return fileslist

path = "/usr/bin"
files = displayFiles(path)
#print(files)
for file in files:
    print(file)