name = "python programming"

print(id(name))

alist = [10,20,30]
print(id(alist))
print(sum(alist))
print(max(alist))
print(min(alist))
print(type(name))

if isinstance(name,str):
    print(name.upper())
    
if isinstance(alist,dict):
    print("XYZ")
    
book = {"chap1":10 ,"chap2":[10,20,30]}
for key,value in book.items():
    if isinstance(value,int):
        print(key,value + 10)
    elif isinstance(value,list):
        getsum = sum(value)
        print(key,getsum)

