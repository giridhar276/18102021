

        
#replace Batsman   with bastaman - Captain

with open("csvfiles/IPLData.csv","r") as fobj:
    with open("csvfiles/IPLUpdated.csv","w") as fw:
        for line in fobj:
            line = line.strip()
            line = line.replace("Batsman","Batsman-Captain")
            fw.write(line + "\n")
            
import csv
with open("csvfiles/IPLData.csv","r") as fobj:
    reader = csv.reader(fobj)
    with open("csvfiles/IPLUpdated.csv","w") as fw:
        for line in reader:
            #line = line.strip()
            if "Batsman" in line:
                #line = line.replace("Batsman","Batsman-Captain")
                line[5] = "bastaman - captain"
                fw.write(line + "\n")