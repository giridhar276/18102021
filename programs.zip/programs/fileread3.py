

        
#replace Batsman   with bastaman - Captain

with open("csvfiles/IPLData.csv","r") as fobj:
    with open("csvfiles/IPLUpdated.csv","w") as fw:
        for line in fobj:
            line = line.strip()
            line = line.replace("Batsman","Batsman-Captain")
            fw.write(line + "\n")