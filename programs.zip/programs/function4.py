



# keyword arguments

def display(second,first):
    print(first,second)


display(first = 10, second = 20)


