
# function body
def display(first,second):
    return first + second

print("This is the beginning point")
# calling function
getsum = display(10,20)
print(getsum)
print("This is the ending point")
