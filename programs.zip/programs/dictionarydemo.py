

book = {"chap1":10 ,"chap2":20 ,"chap3":30 }

print(book["chap1"])

print(book["chap1"] ,book["chap2"])


print(book)

# new key-value pair

book["chap4"] = 40
print("ITEMS :", book)

