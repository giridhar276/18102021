name = "python programming"




print(name.upper())
print(name.lower())

print(name.capitalize())
print(name.center(40))
print(name.center(40,"*"))
print(name.isupper())
print(name.islower())

a,b = 10,200
if a < b:
    print("A is greater")
    print("still in if")
    print("stil inside if")
else :
    print("B IS GREATER")
    print("ELSE PART")
    print("")

    
if name.islower():
    print("String is lower")
else:
    print("String is upper")
        
print(name)
print(name.split(" "))

print(name.replace("python","ruby"))

print(name.count("p"))


aname = "  python  "
print(len(aname))

print(len(aname.strip()))
print(len(aname.rstrip()))
print(len(aname.lstrip()))



if name.startswith("pyt"):
    print("STRING IS STARTING WITH PYT")
else:
    print("String is not starting with pyt")
    
    

if name.endswith("g"):
    print("ITS PYTHON PROGRAMMING")
else:
    print("ITS JAVA PROGARMMING")
    








    
    
    
    



    
    
    
