
'''
Batsman     : 44 players
bowler      : 36 players
Allrounder  : 10 players
W.keeper    :  5 players
'''

import csv
playerlist = list()   
with open("csvfiles/IPLData.csv","r") as fobj:
    header = fobj.readline()
    reader = csv.reader(fobj)
    for row in reader:
        playingrole = row[5]
        playerlist.append(playingrole)
#print(playerlist)
        
for role in set(playerlist):
    print(role.ljust(10) ,  playerlist.count(role))
