# display files from current directory
import os
def displayFiles():
    for file in os.listdir():
        print(file)
displayFiles()

# display files from someother directory
import os
def displayFiles(path):
    for file in os.listdir(path):
        print(file)

path = "/usr/bin"
displayFiles(path)

#3
import os
def displayOnlypyFiles():
    for file in os.listdir():
        if os.path.isfile(file) and  file.endswith(".py"):
            print(file , "is python file")
            
displayOnlypyFiles()


