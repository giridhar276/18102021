


atup = (10,20,56,4)



# count
# index