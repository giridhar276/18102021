
# function body

# fixed arguments

def display(first,second,third):
    print(first)
    print(second)
    print(third)


print("This is the beginning point")
# calling function
display(10,20)
print("This is the ending point")

