from ipaddress import IPv4Network

# mock link data

g_links = [
    {'local': dict(name='leaf-1', ifname='swp1'),
     'remote': dict(name='rtr-1', ifname='eth1/1')},

    {'local': dict(name='leaf-1', ifname='swp2'),
     'remote': dict(name='rtr-2', ifname='eth2/1')},

    {'local': dict(name='leaf-2', ifname='swp1'),
     'remote': dict(name='rtr-1', ifname='eth1/2')},

    {'local': dict(name='leaf-2', ifname='swp2'),
     'remote': dict(name='rtr-2', ifname='eth2/2')}
]


# ### -------------------------------------------------------------------------
# ###                  demo using 'ipaddress' to subnet IP pool
# ### -------------------------------------------------------------------------

def demo_subneting_links(links):
    """
    The goal of this function is to assign the link peer ip_addr
    values with /31 addresses taken from a pool.
    There are two addresses in a /31.  The first address is
    assigned to the 'local' side of the link and the last
    address is assigned to the 'remote' side of the link
    """

    # mock that we've received a small IP pool from a JSON call,
    # returns unicode

    address_pool = u'1.1.1.0/28'

    # re-subnet the links pool into /31.  the IPv4Netowrk subnets
    # method returns a generator object we can iterate through

    subnets = IPv4Network(address_pool).subnets(new_prefix=31)

    # iterate through each link along with the /31 subnet for the link

    for this_link, this_net in zip(links, subnets):

        # extract the first and last IP addr value from the
        # link subnet and format it with the prefixlen

        first_ip, last_ip = map(('{}/%s' % this_net.prefixlen).format,
                                [this_net[0], this_net[-1]])

        # assign the first to the local side and the last
        # to the remote side

        this_link['local']['ip_prefix'] = first_ip
        this_link['remote']['ip_prefix'] = last_ip


# ### -------------------------------------------------------------------------
# ###                display the results of the ipaddr assignment
# ### -------------------------------------------------------------------------

def demo_show_links(links):
    for link in links:
        lcl, rmt = link['local'], link['remote']

        print("{}:{} {} \t\t {}:{} {}".format(
            lcl['name'], lcl['ifname'], lcl['ip_prefix'],
            rmt['name'], rmt['ifname'], rmt['ip_prefix']))


demo_subneting_links(g_links)
demo_show_links(g_links)
