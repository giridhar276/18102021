#


import SubnetTree
t = SubnetTree.SubnetTree()
t["10.1.0.0/16"] = "Network 1"
t["10.1.42.0/24"] = "Network 1, Subnet 42"

print("10.1.42.1" in t)
print(t["10.1.42.1"])
print(t["10.1.43.1"])
print("10.20.1.1" in t)


try:
    print(t["10.20.1.1"])
except KeyError as err:
    print("Error: %s not found" % err)
    
    
#link https://github.com/zeek/pysubnettree