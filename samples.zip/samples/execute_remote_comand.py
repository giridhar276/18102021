

import paramiko
	
host = '192.168.19.131'
port = 22
username = 'user'
password = 'password'

ssh = paramiko.SSHClient()	
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname=host, port=port, username=username, password = 'password')

stdin,stdout,stderr = ssh.exec_command("ls /home/user/Desktop/scripts/")	

for line in stdout.read().splitlines():
    line = line.decode('utf-8')
    print(line)

ssh.close()

