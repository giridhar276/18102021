
import ipaddress

print(ipaddress.ip_address('192.0.2.1'))

print(ipaddress.ip_address('2001:DB8::1'))

#Addresses can also be created directly from integers. Values that will fit within 32 bits are assumed to be IPv4 addresses:

print(ipaddress.ip_address(3221225985))

print(ipaddress.ip_address(42540766411282592856903984951653826561))

#Defining Networks

'''
Host addresses are usually grouped together into IP networks, 
so ipaddress provides a way to create, inspect and manipulate network definitions. 
IP network objects are constructed from strings that define the range of host addresses that are part of that network. The simplest form for that information is a “network address/network prefix” pair,
'''

print(ipaddress.ip_network('192.0.2.0/24'))

print(ipaddress.ip_network('2001:db8::0/96'))

print(ipaddress.ip_network(3221225984))


#Host Interfaces
'''
 if you need to describe an address on a particular network, neither the address nor the network classes are sufficient. Notation like 192.0.2.1/24 is commonly used by network engineers and the people who write tools for firewalls and routers as shorthand for “the host 192.0.2.1 on the network
'''

print(ipaddress.ip_interface('192.0.2.1/24'))




net4 = ipaddress.ip_network('192.0.2.0/24')
for x in net4.hosts():
    print(x)  





net4 = ipaddress.ip_network('192.0.2.0/24')

print(net4.netmask)


print(net4.hostmask)

net6 = ipaddress.ip_network('2001:db8::0/96')
print(net6.netmask)


print(net6.hostmask)


#Exploding or compressing the address:


print(net6.exploded)

print(net6.compressed)



#Comparisons
print(ipaddress.ip_address('192.0.2.1') < ipaddress.ip_address('192.0.2.2'))




#Getting more detail when instance creation fails
print(ipaddress.ip_address("192.168.0.256"))



try:
    ipaddress.ip_address("192.168.0.256")
except (ipaddress.AddressValueError,ValueError) as err:
    print("Error:", err)




from ipaddress import IPv4Interface

ifc = IPv4Interface("192.168.1.6/24")
print(ifc.ip)  # The host IP address

print(ifc.network)  # Network in which the host IP resides



