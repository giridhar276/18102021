


import paramiko
import os
	
host = '192.168.19.131'
port = 22
username = 'user'
password = 'password'
	
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname=host,  username=username, password = 'password')
sftp = ssh.open_sftp()

remote_path = '/tmp/'

local_path = '/home/user/Desktop/localfiles/'

for file in os.listdir(local_path):
    file_local = local_path + file
    file_remote = remote_path + file
    sftp.put(file_local , file_remote)
    print(file_local  +  '  >>>  ' + file_remote )

ssh.close()
sftp.close()

