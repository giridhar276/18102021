from netaddr import *
import pprint

ip = IPAddress('192.0.2.1')
# print ip version
print(ip.version)

## str format
print(str(ip))

print('%s' % ip)

print(ip.format())

print(int(ip))
print(hex(ip))
print(ip.bin)
print(ip.bits())


#Representing networks and subnets
ip = IPNetwork('192.0.2.1')

print(ip.ip)

print(ip.network, ip.broadcast)

# netmask and hostmask
print(ip.netmask, ip.hostmask)

print(ip.size)






ip = IPNetwork('192.0.2.0/24')
print(ip.ip)

print(ip.network, ip.broadcast)

print(ip.netmask, ip.hostmask)

print(ip.size)






ip = IPNetwork('192.0.3.112/22')
print(ip.ip)

print(ip.network, ip.broadcast)

print(ip.netmask, ip.hostmask)

print(ip.size)


'''
Internally, each IPNetwork object only stores 3 values :

the IP address value as an unsigned integer
a reference to the IP protocol module for the IP version being represented
the CIDR prefix bitmask
All the other values are calculated on-the-fly on access.

It is possible to adjust the IP address value and the CIDR prefix after object instantiation.
'''


ip = IPNetwork('0.0.0.0/0')
print(ip)

ip.value = 3221225985
print(ip)

print(ip.prefixlen)

ip.prefixlen = 23
print(ip)



#The prefix length can also be changed by specifying a subnet mask:

ip = IPNetwork('192.168.1.0/24')
ip.netmask = '255.255.0.0'
print(ip)

ip = IPNetwork('fe80::dead:beef/64')
ip.netmask = 'ffff:ffff::'
print(ip)
print(ip.cidr)


'''
If you want to access information about each of the various IP addresses that form the IP subnet, this is available by performing pass through calls to sub methods of each IPAddress object.

For example if you want to see a binary digit representation of each address you can do the following.
'''

print(ip.ip.bits())

print(ip.network.bits())

print(ip.netmask.bits())

print(ip.broadcast.bits())





#IPv6 support
ip = IPAddress(0, 6)
print(ip)

ip = IPNetwork('fe80::dead:beef/64')
print(str(ip), ip.prefixlen, ip.version)

print(hex(ip.ip))

print(ip.ip.bits())



#IPv4 to IPv6 conversion
ip = IPAddress('192.0.2.15').ipv4()
print(ip)

ip = IPAddress('192.0.2.15').ipv6()
print(ip)

print(ip.is_ipv4_mapped())

print(ip.is_ipv4_compat())






print(IPAddress('192.0.2.15').ipv6(ipv4_compatible=True))

print(IPAddress('192.0.2.15').ipv6(ipv4_compatible=True).is_ipv4_compat())

print(IPAddress('192.0.2.15').ipv6(True))

ip = IPNetwork('192.0.2.1/23')
print(ip.ipv4())

print(ip.ipv6())
print(ip.ipv6(ipv4_compatible=True))




#IPv6 to IPv4 conversion
print(IPNetwork('::ffff:192.0.2.1/119').ipv6())

print(IPNetwork('::ffff:192.0.2.1/119').ipv6(ipv4_compatible=True))

print(IPNetwork('::ffff:192.0.2.1/119').ipv4())

print(IPNetwork('::192.0.2.1/119').ipv4())




### List Operations
#If you treat an IPNetwork object as if it were a standard Python list object it will give you access to a list of individual IP address objects. 
ip = IPNetwork('192.0.2.18/29')
ip_list = list(ip)
print(len(ip_list))


for ipadd in ip_list:
    print(ipadd)



#Indexing
print(ip[0])

print(ip[1])

print(ip[-1])



#working with large IP subnets 
for ip in IPNetwork('192.0.2.0/23'):
    print('%s' % ip)



#In IPv4 networks you only usually assign the addresses between the network and broadcast addresses to actual host interfaces on systems.
    
for ip in IPNetwork('192.0.2.18/29').iter_hosts():
    print('%s' % ip)
    
    
#Sorting IP addresses and networks
#It is fairly common and useful to be able to sort IP addresses and networks canonically
    
import random
ip_list = list(IPNetwork('192.0.2.128/28'))
print()
random.shuffle(ip_list)
print(ip_list)
print(sorted(ip_list))





ip_list = [
IPAddress('192.0.2.130'),
IPAddress('10.0.0.1'),
IPNetwork('192.0.2.128/28'),
IPNetwork('192.0.3.0/24'),
IPNetwork('192.0.2.0/24'),
IPNetwork('fe80::/64'),
IPAddress('::'),
IPNetwork('172.24/12')]

random.shuffle(ip_list)
ip_list.sort()
pprint.pprint(ip_list)



#Supernets and subnets


ip = IPNetwork('172.24.0.0/16')
#print(ip.subnet(23))
subnets = list(ip.subnet(23))
# length of subnets
print(len(subnets))

for ip in subnets:
    print(ip)




#It is also possible to retrieve the list of supernets that a given IP address or subnet belongs to. You can also specify an optional limit.
#we return a list rather than a generator because the potential list of values is of a predictable size (no more than 31 subnets for an IPv4 address and 127 for IPv6)
ip = IPNetwork('192.0.2.114')
supernets = ip.supernet(22)
pprint.pprint(supernets)




ip_list = list(iter_iprange('192.0.2.1', '192.0.2.14'))
print(len(ip_list))

print(ip_list)

for val in ip_list:
    print(val)
    
    
    
'''
It is equally nice to know what the actual list of CIDR subnets is that would correctly cover this non-aligned range of addresses.

Here cidr_merge() comes to the rescue once more.
'''

print(cidr_merge(ip_list))




#IP address categorisation

#IP addresses fall into several categories, not all of which are suitable for assignment as host addresses.

#Unicast
print(IPAddress('192.0.2.1').is_unicast())

print(IPAddress('fe80::1').is_unicast())



#Multicast

print(IPAddress('239.192.0.1').is_multicast())

print(IPAddress('ff00::1').is_multicast())



'''
Private
Found on intranets and used behind NAT routers.
'''

print(IPAddress('172.24.0.1').is_private())

print(IPAddress('10.0.0.1').is_private())

print(IPAddress('192.168.0.1').is_private())

print(IPAddress('fc00::1').is_private())



'''Reserved
Addresses in reserved ranges are not available for general use.
'''

print(IPAddress('253.100.0.100').is_reserved())



'''
Netmasks
A bitmask used to divide an IP address into its network address and host address.
'''

print(IPAddress('255.255.254.0').is_netmask())



'''
Hostmasks
Similar to a netmask but with the all the bits flipped the opposite way.
'''
print(IPAddress('0.0.1.255').is_hostmask())



'''
Loopback
These addresses are used internally within an IP network stack and packets sent to these addresses are not distributed via a physical network connection.
'''

print(IPAddress('127.0.0.1').is_loopback())

print(IPAddress('::1').is_loopback())




'''
DNS support
It is a common administrative task to generate reverse IP lookups for DNS. This is particularly arduous for IPv6 addresses.
'''
print(IPAddress('172.24.0.13').reverse_dns)
