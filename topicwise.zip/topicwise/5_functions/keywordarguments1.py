def func(**keyvalues):
    print(keyvalues)
    for i in keyvalues:
        print(i,keyvalues[i])

func()
func(de="Germnan",en="English",fr="French")


 
