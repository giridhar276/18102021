print("My values are {0} and {1}".format(100,200))
