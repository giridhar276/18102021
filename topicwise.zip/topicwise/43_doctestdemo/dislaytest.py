


def display():
    '''
    this is the commented line
    '''

print(display.__doc__)
