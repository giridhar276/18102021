#!/usr/bin/python

import Student.person
import Student.branch
import Student.marks


Student.person.personInfo()
Student.branch.branchInfo()
Student.marks.marksInfo()

