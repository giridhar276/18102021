#!/usr/bin/python

# import the module
import fibonacci

if __name__ == "__main__":
    import sys
    fibonacci.fibo(int(sys.argv[1]))
