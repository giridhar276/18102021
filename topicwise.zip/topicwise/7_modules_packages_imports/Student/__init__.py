# Student/__init__.py

__all__ = ["person","branch","marks"]
