import tkinter
top = tkinter.Tk()
# Code to add widgets will go here...
top.mainloop()
