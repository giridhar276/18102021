
import subprocess

output = subprocess.getstatusoutput('aws iam list-users')

print(type(output))

