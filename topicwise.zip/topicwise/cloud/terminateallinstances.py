import boto3
ec2 = boto3.resource('ec2','ap-south-1')
for instance in ec2.instances.all():
    instance = ec2.Instance(instance.id)
    response = instance.terminate()
    print(response)
